
/**
 * @desc React
 */
import React from 'react';
import ReactDOM from 'react-dom';

/**
 * @desc Styles of challenge
 */
import './all.css';




class App extends React.Component{

  constructor(props){

    /* @ */
    super(props);

    /* @ */
    this.visitants = [];

    return this;

  }

  render(){
    return (<main id="root">
              <FormView visitants={this.visitants} />
              <VisitantsView visitants={this.visitants} />
            </main>
    );

  }

}


/**
 * @name FormView
 * @desc view of form
 */
class FormView extends React.Component{
  
    /**
       * @name constructor
       * @desc props by default
     */
    constructor(props){

      /* @ */
      super(props);
      
      /* @ */
      this.visitants = props.visitants;
      this.countrys   = [];
      this.form       = {
          "name"      : "",
          "country"   : "",
          "date"      : ""
      };

      /* @ */
      this.fetchCountrys();

    }


    /**
       * @name componentWillUnmount
       * @desc after component initialize
     */
    fetchCountrys(){

      /* @ */
      fetch('https://restcountries.eu/rest/v2/region/Americas')
        .then(e => e.json())
        .then(function(response){

          /* @ */
          this.countrys = response;

          /* @ */
          this.setState(this.countrys);

        }.bind(this));

    }

    /**
       * @name countryElement
       * @desc Element option of select countrys
    */
    countryElement(country,index){

      /* @ */
      return (
        <option index={index} value={country.id}>{country.name} - {country.languages[0].name}</option>
      );

    }

    /**
       * @name saveVisit
       * @desc save the form of visit
     */
    saveVisit(e){

      /* @ */
      e.preventDefault();

      /* @ */
      this.props.visitants.push({
        "name"    : this.refs.visit_name.value,
        "country" : this.refs.visit_country.value,
        "date"    : this.refs.visit_date.value
      });
      this.setState(this.props.visitants);

    }


    render(){
      return(
        <section>

          <form onSubmit={this.saveVisit.bind(this)}>
            <fieldset>
              <label>Nombre</label> <input type="text" placeholder="Tu Nombre aquí" ref="visit_name" />
            </fieldset>
            <fieldset>
              <label>Pais</label>
              <select ref="visit_country">
                {
                  this.countrys.map(this.countryElement.bind(this))
                }
              </select>
            </fieldset>
            <fieldset>
              <label>Cumpleaños:<sub>(dd/mm/aaaa)</sub></label>
              <input type="date" ref="visit_date" />
            </fieldset>
            <button>Saludar</button>
          </form>

          {          
            <output style={(this.form.name === '' ? {display:'none'} : {})} >
              Hola {this.form.name} de {this.form.country} el día {new Date(this.form.date).getDay()}
              del mes {new Date(this.form.date).getMonth()} tendrás {new Date(this.form.date).getFullYear() - new Date().getFullYear()} años
            </output>
          }

        </section>
      );
    }

}


/**
 * @name FormView
 * @desc view of form
 */
class VisitantsView extends React.Component{

      /**
       * @name constructor
       * @desc props by default
     */
    constructor(props){

      /* @ */
      super(props);
      
      /* @ */
      this.visitants = props.visitants;
  
    }

  /**
   * @name insertVisitants
   * @desc Structure of a visitant
   * @return <LI>
   */
  insertVisitants(person,key){
    return (<li key={key}>
              {person.name} - {person.country} - {person.date}
            </li>);
  }

  render(){

    return (
      <section>
        <h1>Visitantes Anteriores</h1>
        <ul>
          {
            this.visitants.map(this.insertVisitants.bind(this))
          }
        </ul>
      </section>
    );


  }



}



ReactDOM.render(<App />,document.getElementById('root'));
